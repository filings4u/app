/* screenings4u Employer rebuild compatibility file: employer-document-library-selector.js.
   Employer pages now use employer-runtime.js. This file intentionally performs no DOM work. */
(() => {})();
