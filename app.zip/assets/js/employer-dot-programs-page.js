/* screenings4u Employer rebuild compatibility file: employer-dot-programs-page.js.
   Employer pages now use employer-runtime.js. This file intentionally performs no DOM work. */
(() => {})();
